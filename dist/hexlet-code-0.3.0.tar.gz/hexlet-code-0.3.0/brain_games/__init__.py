"""Docstring to make linter feel good."""
