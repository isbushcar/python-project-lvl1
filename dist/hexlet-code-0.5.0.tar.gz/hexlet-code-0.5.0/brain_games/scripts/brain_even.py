"""Brain-even game script."""


from brain_games.games.game_even import game_even

from brain_games.game_interface import game_start, game_end


def main():
    """Made to run a brain-even game."""
    name = game_start()
    game_result = game_even()
    if game_result == 'win':
        print('Congratulations, {0}'.format(name))
    if game_result == 'lose':
        print("Let's try again, {0}".format(name))
